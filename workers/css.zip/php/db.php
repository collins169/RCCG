<?php
    $connect = mysqli_connect('localhost','bluerayg_collins','Ads13a00106y','bluerayg_rccgambprotocolgh') or die ("Could not connect to database contact system administator");
//if($connect){
//    echo "Connected";
//} else {
//    echo "Failed to connect";
//}
?>